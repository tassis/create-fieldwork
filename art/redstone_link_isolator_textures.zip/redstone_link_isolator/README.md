# 隔離器六面材質模板

六面各自獨立、16×16、PNG；另附`up_active.png`供ACTIVE頂面使用。

| 檔案 | 面（Minecraft方塊本地軸） |
|---|---|
| `north.png` | 北，-Z |
| `south.png` | 南，+Z |
| `east.png` | 東，+X |
| `west.png` | 西，-X |
| `up.png` | 上，+Y，inactive |
| `down.png` | 下，-Y |
| `up_active.png` | 上，+Y，ACTIVE |

方塊沒有獨立FACING屬性；飛船旋轉時材質隨方塊/飛船的本地軸旋轉。

`cube_net.png`是64×48的六面展開快照，`preview.png`是其8倍nearest-neighbor放大預覽：

```text
         up
 west   north   east   south
        down
```

請以七張獨立面PNG作為編輯原稿。展開圖只是查看用，不是目前Minecraft模型使用的packed atlas，也不會在你編輯面PNG後自動更新。

## 目前接入狀態

這些是自行生成的占位材質，保留黑紫側面、金色inactive頂面與紅色ACTIVE頂面的配色方向，**不是從Minecraft或依賴JAR複製的原材質**。

**這套占位稿已接入main模型。** 遊戲實際使用七張PNG的目錄為：

`src/main/resources/assets/create_fieldwork/textures/block/redstone_link_isolator/`

之後最直接的方式是改上面main目錄的PNG；六面各自獨立，ACTIVE只換`up_active.png`。這個art資料夾與ZIP保留為原始模板／預覽快照，改main不會自動同步回這裡。

## 編輯與同步

inactive模型在`models/block/redstone_link_isolator.json`，ACTIVE模型在`models/block/redstone_link_isolator_active.json`；兩個art JSON模板已套用到相對應的main位置。Blockstate與item model不必變。

如果選擇改art原稿而非main，可用`--install --force`將七張art PNG複製到main；**會覆蓋main的七張材質，請先確認哪份是最新稿**。模型JSON不會被腳本改寫。

重新build、關閉遊戲/server後換JAR；新hash需重新核對。ZIP不是可直接丟入resourcepacks的資源包。

JSON模板已用`minecraft:block/cube`分開指定六面，ACTIVE版本繼承同一模型，只覆蓋`up`。

## 重現與檢查

```sh
python3 scripts/export-isolator-textures.py --check
python3 scripts/export-isolator-textures.py --check-installed
# 明確把art原稿覆蓋到main（不是重新生成占位稿）：
python3 scripts/export-isolator-textures.py --install --force
# 重新生成會覆蓋手繪稿，因此預設拒絕已有PNG；確認要丟棄修改才使用：
python3 scripts/export-isolator-textures.py --force
```

腳本只用Python標準函式庫，不需要Pillow。預設只生成art；僅`--install`會寫main的七張PNG，已有檔案時必須明確加`--force`。`--check-installed`只檢查main PNG與六面/ACTIVE模型引用，允許main與art已各自編輯；腳本不會build或替換JAR。

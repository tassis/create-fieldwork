# Original placeholder + material rim only

Owner-requested minimal revision: use the original placeholder texture, changing
**only the outer two pixels** of the side/bottom edges to andesite-gray or brass-gold edging.
Both top textures (`up`, `up_active`) remain entirely identical to the original
placeholder, with no added rim. Both materials share those unchanged tops.
All inner 12×12 pixels remain exactly identical to the original generator output,
including dark panel grain, square border, four corner rivets and top indicator.
No wood, key, new symbol or redesigned interior.

The rim palette was revised against the actual audited **Create6.0.10**
`andesite_casing.png` / `brass_casing.png`: andesite now uses exact sampled dark
frame colors: primary `#505351` (80/83/81), midtone `#60635F` (96/99/95),
shadow `#404543` (64/69/67), and sparse highlights `#686C68` (104/108/104).
The brighter130–179 gray-green colors from earlier drafts are no longer used in
its rim. Brass uses pale gold RGB255/235/140 and247/203/108,
with warm copper-brown outer edging. The earlier near-black outline and halved
shadow colors are removed. This references upstream colors, not copied texture
pixel layout; the original placeholder interior remains untouched.

Each material folder has seven 16×16 PNGs, a cube net, enlarged net and two
isometric previews. `comparison.png` shows both materials OFF/ON.
`isolator_variants.zip` includes both sets, previews and this guide.

```sh
python3 scripts/export-isolator-variants.py --style rim
python3 scripts/export-isolator-variants.py --style rim --check
```

The check also verifies the untouched 12×12 interior for every face and material,
and full 16×16 equality with the original for both top states.
Existing outputs require explicit `--force` to replace. Art only: no production
textures/models/recipes/version changed. Previews are illustrations, not game
screenshots. Original repository artwork, GPL-3.0-only.
